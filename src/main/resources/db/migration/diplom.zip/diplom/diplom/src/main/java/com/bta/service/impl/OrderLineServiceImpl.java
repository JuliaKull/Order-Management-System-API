package com.bta.service.impl;

import com.bta.dto.CustomerDTO;
import com.bta.dto.ProductDTO;
import com.bta.mapper.WebMapper;
import com.bta.model.Customer;
import com.bta.repository.OrderLineRepository;
import com.bta.service.OrderLineService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class OrderLineServiceImpl implements OrderLineService {

    @Autowired
    private WebMapper<CustomerDTO, Customer> webMapper;

    @Autowired
    private OrderLineRepository orderLineRepository;


    @Override
    public void create(ProductDTO product) {

    }

    @Override
    public ProductDTO update(ProductDTO product) {
        return null;
    }

    @Override
    public List<ProductDTO> getAll() {
        return null;
    }
}

package com.bta.service;

import com.bta.dto.CustomerOrderDTO;

public interface CustomerOrderService {

    void create(CustomerOrderDTO customerOrder);
}

package com.bta.model;

import lombok.*;

import javax.persistence.*;

@Setter
@Getter
@Builder

@NoArgsConstructor
@AllArgsConstructor
@ToString

@Entity
@Table(name = "orderline")
public class OrderLine extends AbstractBaseEntity{


    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;

    private int quantity;

    @ManyToOne
    @JoinColumn(name = "customer_order_id")
    private CustomerOrder customerOrder;
}

package com.bta.email;

public interface EmailSender {

    void sendEmail(String to, String body, String title);
}

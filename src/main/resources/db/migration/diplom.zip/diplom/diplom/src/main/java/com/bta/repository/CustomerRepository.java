package com.bta.repository;

import com.bta.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository   //бин который отвечает за работу с БД
public interface CustomerRepository extends CrudRepository<Customer,Long> {
Customer findByEmail(String email);
}

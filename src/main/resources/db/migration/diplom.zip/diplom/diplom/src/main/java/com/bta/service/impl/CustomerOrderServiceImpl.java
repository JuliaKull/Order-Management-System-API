package com.bta.service.impl;

import com.bta.dto.CustomerOrderDTO;
import com.bta.mapper.WebMapper;
import com.bta.model.CustomerOrder;
import com.bta.repository.CustomerOrderRepository;
import com.bta.service.CustomerOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZonedDateTime;

@Service
public class CustomerOrderServiceImpl implements CustomerOrderService {

    @Autowired
    private WebMapper<CustomerOrderDTO, CustomerOrder> mapper;

    private CustomerOrderRepository repository;

    @Override
    @Transactional
    public void create(CustomerOrderDTO customerOrder) {
        customerOrder.setSubmissionDate(ZonedDateTime.now());
       final var orderToCreate =  mapper.toEntity(customerOrder);
       repository.save(orderToCreate);

    }
}

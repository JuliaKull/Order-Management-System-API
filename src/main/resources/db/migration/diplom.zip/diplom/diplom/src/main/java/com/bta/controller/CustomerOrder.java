package com.bta.controller;

import com.bta.dto.CustomerOrderDTO;
import com.bta.service.CustomerOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;
@RequestMapping("/customer-order")
@RestController
public class CustomerOrder {

    @Autowired
    private CustomerOrderService customerOrderService;

    @PostMapping("/create")
    public ResponseEntity<?>create(@RequestBody CustomerOrderDTO customerOrder){
        customerOrderService.create(customerOrder);
        return new ResponseEntity(HttpStatus.OK);
    }
}

package com.bta.email;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Component
public class EmailSenderImpl implements EmailSender{

    @Autowired
    private JavaMailSender javaMailSender;

    @Override
    public void sendEmail(String to, String body, String title) {
        final SimpleMailMessage mailMessage = new SimpleMailMessage();
       mailMessage.setTo(to);
       mailMessage.setSubject(body);
       mailMessage.setText(title);
       javaMailSender.send(mailMessage);

    }
}

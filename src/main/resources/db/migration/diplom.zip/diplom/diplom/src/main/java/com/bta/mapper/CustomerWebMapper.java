package com.bta.mapper;

import com.bta.dto.CustomerDTO;
import com.bta.model.Customer;
import org.springframework.stereotype.Component;

@Component
public class CustomerWebMapper implements WebMapper <CustomerDTO,Customer>{
    @Override
    public CustomerDTO toDTO(Customer entity) {
        return CustomerDTO.builder()
                .email(entity.getEmail())
                .lastName(entity.getLastName())
                .firstName(entity.getFirstName())
                .registrationCode(entity.getRegistrationCode())
                .build();

    }

    @Override
    public Customer toEntity(CustomerDTO dto) {
        return Customer.builder()
                .email(dto.getEmail())
                .lastName(dto.getLastName())
                .firstName(dto.getFirstName())
                .registrationCode(dto.getRegistrationCode())
                .build();
    }
}

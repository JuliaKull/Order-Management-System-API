package com.bta.service;

import com.bta.dto.ProductDTO;

import java.util.List;

public interface OrderLineService {

    void create(ProductDTO product);

    ProductDTO update(ProductDTO product);

    List<ProductDTO> getAll();
}

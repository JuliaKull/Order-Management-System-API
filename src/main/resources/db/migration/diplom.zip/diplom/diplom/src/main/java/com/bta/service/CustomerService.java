package com.bta.service;

import com.bta.dto.CustomerDTO;
import com.bta.model.Customer;

import java.util.List;

public interface CustomerService {

    void create(CustomerDTO customer);

    void update(CustomerDTO customer);

    List<CustomerDTO> getAll();
}

package com.bta.controller;

import com.bta.dto.ProductDTO;
import com.bta.service.OrderLineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public class OrderLineController {

    @Autowired
    private OrderLineService orderLineService;


    @GetMapping("/all")
    public List<ProductDTO> all(){
        return orderLineService.getAll();
    }

    @PostMapping("/create")
    public ResponseEntity<ProductDTO> create(@RequestBody ProductDTO product){
        orderLineService.create(product);
        return new ResponseEntity<>(product, HttpStatus.OK);
    }
    @PutMapping("/update")
    public ResponseEntity<ProductDTO> update(@RequestBody ProductDTO product){
        final ProductDTO updatedProduct = orderLineService.update(product);
        return new ResponseEntity<>(product, HttpStatus.OK);
    }
}

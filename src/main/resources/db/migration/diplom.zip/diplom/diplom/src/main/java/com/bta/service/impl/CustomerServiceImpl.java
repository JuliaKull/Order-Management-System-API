package com.bta.service.impl;

import com.bta.dto.CustomerDTO;
import com.bta.mapper.WebMapper;
import com.bta.model.Customer;
import com.bta.repository.CustomerRepository;
import com.bta.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerRepository repository;

    @Autowired
    private WebMapper<CustomerDTO, Customer> webMapper;

    @Override
    public void create(CustomerDTO customer) {
       final Customer entity = webMapper.toEntity(customer);
       repository.save(entity);
    }

    @Override
    public void update(CustomerDTO customer) {
        create(customer);
    }

    @Override
    public List<CustomerDTO> getAll(){
        return webMapper.toDtos((List<Customer>) repository.findAll());
    }
}

package com.bta.mapper;

import com.bta.dto.CustomerDTO;
import com.bta.dto.OrderLineDTO;
import com.bta.model.Customer;
import com.bta.model.OrderLine;
import org.springframework.stereotype.Component;

@Component
public class OrderLineWebMapper implements WebMapper <OrderLineDTO, OrderLine>{
    @Override
    public OrderLineDTO toDTO(OrderLine entity) {
        return OrderLineDTO.builder()
                .product(entity.getProduct())
                .quantity(entity.getQuantity())
                .customerOrder(entity.getCustomerOrder())
                .build();

    }

    @Override
    public OrderLine toEntity(OrderLineDTO dto) {
        return OrderLine.builder()
                .product(dto.getProduct())
                .quantity(dto.getQuantity())
                .customerOrder(dto.getCustomerOrder())
                .build();
    }
}

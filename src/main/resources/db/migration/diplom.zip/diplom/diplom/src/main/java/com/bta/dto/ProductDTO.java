package com.bta.dto;

import com.bta.model.OrderLine;
import lombok.Builder;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.OneToMany;
import javax.validation.constraints.Size;
import java.util.List;


@Data
@Builder
public class ProductDTO {
    private Long id;

    private String name;

    private Integer skuCode;

    private Integer unitPrice;

    private Integer orderLineCount;
}

package com.bta.mapper;

import com.bta.dto.CustomerDTO;
import com.bta.model.Customer;

import java.util.List;
import java.util.stream.Collectors;

public interface WebMapper <D,E> {
    D toDTO(E entity);

    E toEntity(D dto);

   default List<D> toDtos(List<E> entities){
      return entities.stream()
               .map(entity->toDTO(entity)).collect(Collectors.toList());
   }

   default List<E> toEntities(List<D> dtos){
       return dtos.stream()
               .map(dto->toEntity(dto)).collect(Collectors.toList());}

}

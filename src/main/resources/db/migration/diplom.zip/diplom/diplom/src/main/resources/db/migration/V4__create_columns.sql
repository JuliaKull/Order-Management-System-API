alter table customer rename column firstName to first_name;
alter table customer rename column lastName to last_name;
alter table customer rename column registrationCode to registration_code;

alter table product rename column skuCode to sku_code;
alter table product rename column unitPrice to unit_code;

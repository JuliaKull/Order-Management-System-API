package com.bta.service.impl;

import com.bta.dto.UserAccountDTO;
import com.bta.email.EmailSender;
import com.bta.mapper.WebMapper;
import com.bta.model.ActivationLink;
import com.bta.model.UserAccount;
import com.bta.repository.ActivationLinkRepository;
import com.bta.repository.UserAccountRepository;
import com.bta.service.UserAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZonedDateTime;
import java.util.UUID;

@Service
public class UserAccountServiceImpl implements UserAccountService {

    @Autowired
    private UserAccountRepository userAccountRepository;

    @Autowired
    private WebMapper<UserAccountDTO, UserAccount> webMapper;

    @Autowired
    private ActivationLinkRepository activationLinkRepository;

    @Autowired
    private EmailSender emailSender;


    @Override
    @Transactional
    public void create(UserAccountDTO userAccountDTO) {
        checkIfUserAccountExist(userAccountDTO);
        final UserAccount newUserAccount = webMapper.toEntity(userAccountDTO);
        processNewUserAccount(newUserAccount);
        final UserAccount saveUserAccount = userAccountRepository.save(newUserAccount);
        final ActivationLink activationLink = createActivationLink(saveUserAccount);
        activationLinkRepository.save(activationLink);
        final String link = "http://localhost:8080/user-account/activate?code="+activationLink.getCode();
        emailSender.sendEmail(userAccountDTO.getEmail(), link, "Please activate your Account" );
    }

    private ActivationLink createActivationLink(UserAccount userAccount){
        return ActivationLink.builder()
                .created(ZonedDateTime.now())
                .code(UUID.randomUUID().toString())
                .userAccount(userAccount)
                .build();
    }

    private void checkIfUserAccountExist(UserAccountDTO userAccountDTO) {
        final var username = userAccountDTO.getUsername();
        final var userAccountFromDB = userAccountRepository.findByUsernameAndActive(username, false);
        if (userAccountFromDB == null) {
            throw new RuntimeException("User with username: " + username + " already registered");
        }
    }

    private void processNewUserAccount(UserAccount newUserAccount){
        newUserAccount.setActive(false);
        newUserAccount.setCreated(ZonedDateTime.now());
    }
}

package com.bta;

import com.bta.repository.CustomerOrderRepository;
import com.bta.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiplomApplication {

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private CustomerOrderRepository customerOrderRepository;

	public static void main(String[] args) {
		SpringApplication.run(DiplomApplication.class, args);
	}

}

package com.bta.repository;

import com.bta.model.ActivationLink;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ActivationLinkRepository extends JpaRepository<ActivationLink,Long> {

}
